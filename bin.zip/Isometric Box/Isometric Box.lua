--[[---------------------------------------------------------------------
  ISOMETRIC BOX GENERATOR for Aseprite (https://aseprite.org)
  Project page: https://sticknologic.itch.io/isobox-for-aseprite

  Converted to extension by:
    John Aerial J. Azcune (@STICKnoLOGIC)
    Twitter/X: http://twitter.com/sticknologic
    Itch.io: https://sticknologic.itch.io

  Forked from::
    Project page: https://sticknologic.itch.io/isobox-for-aseprite
    by Kamil Khadeyev (@darkwark)
    Twitter/X: http://twitter.com/darkwark
    Dribbble: http://dribbble.com/darkwark
    Website: http://darkwark.com
  

  (c) 2024, November 
  All rights reserved and under MIT License
  
  Features:
    + Customize X, Y and Z size of the box
    + Customize colors for each side of the box
    + Custom Stroke and Highlight colors
    + Two types of the box: 3px and 2px corner
  
  Requirements:
    + Aseprite 3.x.x or later
    + Color Mode: any color mode (though its little weird when in gray mode)
  
  Usage:
    + Go to `Layer → New.. → Isometric Box Generator` to run the script
    + You can also press hotkey `Shift + I` to run the script
    
-----------------------------------------------------------------------]]
---------------------------------------
-- VARIABLES --
---------------------------------------
local c;
local colors;

-- Use 3px corner by default:
local use3pxCorner = false;

local maxSize;

local dialog;

local img

---------------------------------------
-- Line Utility --
---------------------------------------
local function drawPixel(x1, y1, color_)
	app.useTool{
		tool = "line",
		color = color_,
		points = {Point(x1,y1)},
		button = MouseButton.left,
		contiguous=true,
	}
end

local function drawLine(x1, y1,x2,y2, color_)
	app.useTool{
		tool = "line",
		color = color_,
		points = {Point(x1,y1),Point(x2,y2)},
		button = MouseButton.left,
		contiguous=true,
	}
end

---------------------------------------
-- Color Utility --
-- Paint Bucket Tool implementation --
---------------------------------------
local function floodFill(x, y, color)
  app.useTool{
		tool = "paint_bucket",
		color = color,
		points = {Point(x,y)},
		contiguous=true,
	}
end
local function colorAsPixel(color)
  return app.pixelColor.rgba(color.red, color.green, color.blue, color.alpha)
end
---------------------------------------
-- ISOMETRIC LINES --
---------------------------------------
local function drawIsoLine(color,x,y,len,toLeft,topView)
  for i=0, len do
    x1 = i*2
    x2 = x1+1
    step=i
    if toLeft then
      x1 = -x1
      x2 = -x2 
    end
    if topView then
      step= -i
    end
    app.useTool{
      tool = "line",
      color = color,
      points = {Point(x+x1, y+step),
      Point(x+x2, y+step)},
      button = MouseButton.left,
      contiguous=true,
    }
  end
end

---------------------------------------
-- FINAL CUBE --
---------------------------------------
local function drawCube(type, xSize, ySize, zSize, color)
  --[[
    Dimensions:
      X: right side
      Y: left side
      Z: is height
    
    Type can be 1 or 2:
      1 is for 3px corner
      2 is for 2px corner
  ]]--
  local centerX = math.floor(app.sprite.width/2)
  local centerY = math.floor(app.sprite.height/2)
  

  local a = (type == 1) and 0 or 1
  local b = (type == 1) and 1 or 0
  
  --top plane
  drawIsoLine(color, centerX-a, centerY, xSize,false,true) --bottom right
  drawIsoLine(color, centerX, centerY, ySize,true,true) --bottom left
  drawIsoLine(color, centerX+xSize*2+b, centerY-xSize, ySize,true,true) --top right
  drawIsoLine(color, centerX-ySize*2-1, centerY-ySize, xSize,false,true) --top left
  
  --bottom plane
  drawIsoLine(color, centerX-a, centerY+zSize, xSize,false,true) --right
  drawIsoLine(color, centerX, centerY+zSize, ySize,true,true) --left

  --vertical lines
  drawLine(centerX-a, centerY, centerX-a, centerY + zSize, color) --middle
  drawLine(centerX-ySize*2-1, centerY-ySize,centerX-ySize*2-1, centerY-ySize + zSize,color) --left
  drawLine(centerX+xSize*2+b, centerY-xSize, centerX+xSize*2+b, centerY-xSize+ zSize,color) --right
end


------------ Adding Colors: ------------

local function fillCubeSides(topColor, leftColor, rightColor)
  local centerX = math.floor(app.sprite.width/2)
  local centerY = math.floor(app.sprite.height/2)
  
  -- Top Color
  floodFill(centerX, centerY-1, topColor)
  -- Left Color
  floodFill(centerX-2, centerY+1, leftColor)
  -- Right Color
  floodFill(centerX+1, centerY+1, rightColor)
end

local function addHighlight(type, xSize, ySize, zSize, color)
  local centerX = math.floor(app.sprite.width/2)
  local centerY = math.floor(app.sprite.height/2)
  
  -- TYPE1 is for 3px in the middle
  -- TYPE2 is for 2px in the middle
  local alt = (type == 1) and 0 or 1
  
  drawIsoLine(color, centerX-alt, centerY, xSize-1,false,true)
  drawIsoLine(color, centerX, centerY, ySize-1,true,true) 
  drawLine(centerX-alt, centerY,centerX-alt, centerY + zSize-1,color)
  
  drawPixel(centerX-alt, centerY, app.pixelColor.rgba(255, 255, 255, 255))
end

---------------------------------------
-- LAYER MANAGEMENT --
---------------------------------------
local function newLayer(name)
  s = app.sprite
  lyr = s:newLayer()
  lyr.name = name
  s:newCel(lyr, 1)
  img=Image(app.sprite)
  return lyr
end


---------------------------------------
-- USER INTERFACE --
---------------------------------------
function init(plugin)
  plugin:newCommand{
    id="IsoBoxGen",
    title="Isometric Box Generator",
    group="layer_new", --locate this in Layer/New../Isometric Box Generator
    onenabled=function()
    return app.image ~= nil
    end,
    onclick=function()
    if dialog ~=nil then
	    dialog:close()
	    return
	  end
    
    c = app.fgColor;

    -- Default colors:
    colors = {
    stroke = Color{r=0,g=0,b=0, a=255},
    top = app.fgColor,
    left = Color{h=c.hsvHue, s=c.hsvSaturation+0.3, v=c.hsvValue-0.1, a=255},
    right = Color{h=c.hsvHue, s=c.hsvSaturation+0.3, v=c.hsvValue-0.4, a=255},
    highlight = Color{h=c.hsvHue, s=c.hsvSaturation-0.2, v=c.hsvValue+0.2, a=255}
    }

    -- Default Max Sizes:
    maxSize = {
    x = math.floor(app.sprite.width/4), 
    y = math.floor(app.sprite.width/4), 
    z = math.floor(app.sprite.height/2)
    }

    dialog = Dialog{title="[SnL] Isometric Box",notitlebar=false,onclose=function()
			dialog=nil
		end}
    dialog :separator{ text="Size:" }
           :slider {id="ySize", label="Left:", min=1, max=maxSize.y, value=maxSize.y/2}
           :slider {id="xSize", label="Right:", min=1, max=maxSize.x, value=maxSize.x/2}
           :slider {id="zSize", label="Height:", min=3, max=maxSize.z, value=maxSize.z/4}

           :separator{ text="Colors:" }
           :color {id="color", label="Stroke:", color = colors.stroke}
           :color {id="topColor", label="Top:", color = colorAsPixel(colors.top)}
           :color {id="leftColor", label="Left:", color = colorAsPixel(colors.left)}
           :color {id="rightColor", label="Right:", color = colorAsPixel(colors.right)}
           :color {id="highlightColor", label="Highlight:", color = colorAsPixel(colors.highlight)}
  
           :separator()
           :radio {id="typeOne", label="Corner:", text="3 px", selected=use3pxCorner}
           :radio {id="typeTwo", text="2 px", selected=not use3pxCorner}

           :separator()
           :button {id="ok", text="Add Box",onclick=function()
               local data = dialog.data
               app.transaction(function()
                 local cubeType = data.typeOne and 1 or 2
                 newLayer("Isometric ("..data.xSize.." "..data.ySize.." "..data.zSize..")")
                 drawCube(cubeType, data.xSize, data.ySize, data.zSize, data.color)
                 fillCubeSides(data.topColor, data.leftColor, data.rightColor)
                 addHighlight(cubeType, data.xSize, data.ySize, data.zSize, data.highlightColor)
               end)
               --Refresh screen
               app.refresh()
             end
           }
           :show{wait=false}
          end
	}
end

function exit(plugin)
  if dialog ~= nil then
	dialog:close()
  end
end

---------------------------------------

