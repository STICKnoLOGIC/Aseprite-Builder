; ///////////////////////////////////////////////////////////
; // Graphical Installer for Inno Setup                    //
; // Build 6.3.3                                  //
; // Copyright (c) 2011 - 2024 unSigned, s. r. o.          //
; // http://www.graphical-installer.com                    //
; // customers(at)unsigned(dot)sk                          //
; // All Rights Reserved.                                  //
; ///////////////////////////////////////////////////////////
 
; *********************************************
; * This file contains setting for graphical  *
; * interface. Modify them freerly.           *
; ********************************************* 
 
; Script generated with Graphical Installer Wizard.
 
; UI file for Graphical Installer
#define public GraphicalInstallerUI "GraphicalInstallerUI"
 
; Texts colors
#define public TextsColor    "$FFFFFF"
#define public HeadersColor  "$FFFFFF"
#define public InversedColor "$FFFFFF"
 
; Buttons colors
#define public ButtonNormalColor   "$FFFFFF"
#define public ButtonFocusedColor  "$FF8080"
#define public ButtonPressedColor  "$000000"
#define public ButtonDisabledColor "$C0C0C0"
 
; Images - all files must be in the same directory as this .iss file!
#define public TopPicture    "top.png"    ; 690x416 px
#define public InnerPicture  "inner.png"  ; 413x237 px
#define public BottomPicture "bottom.png" ; 690x83 px
#define public ButtonPicture "Sprite.png" ; 80x136 px
 
; File with core functions and procedures
#include "GraphicalInstaller_functions.iss"
  
[Files]
; Pictures with skin 
Source: {#TopPicture};    Flags: dontcopy noencryption;
Source: {#InnerPicture};  Flags: dontcopy noencryption;
Source: {#BottomPicture}; Flags: dontcopy noencryption;
Source: {#ButtonPicture}; Flags: dontcopy noencryption;
; DLLs
Source: botva2.dll;       Flags: dontcopy noencryption;
 
; End of file (EOF)
